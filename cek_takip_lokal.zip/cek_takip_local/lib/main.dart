import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:intl/intl.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Bildirim Servisi Başlatma
  tz.initializeTimeZones();
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  const InitializationSettings initializationSettings =
      InitializationSettings(android: initializationSettingsAndroid);
  
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  runApp(const CheckApp());
}

class CheckApp extends StatelessWidget {
  const CheckApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Çek Takip Premium',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFD4AF37),
          secondary: Color(0xFFFFD700),
          surface: Color(0xFF1E1E1E),
        ),
        useMaterial3: true,
      ),
      home: const DashboardScreen(),
    );
  }
}

// BİN LİK AYRAÇ FORMATI
String formatMoney(double amount) {
  final formatter = NumberFormat.currency(locale: 'tr_TR', symbol: '₺');
  return formatter.format(amount);
}

class CheckItem {
  final String id;
  final String issuedTo;
  final double amount;
  final DateTime issueDate;
  final DateTime dueDate;
  bool isPaid;

  CheckItem({
    required this.id,
    required this.issuedTo,
    required this.amount,
    required this.issueDate,
    required this.dueDate,
    this.isPaid = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'issuedTo': issuedTo,
        'amount': amount,
        'issueDate': issueDate.toIso8601String(),
        'dueDate': dueDate.toIso8601String(),
        'isPaid': isPaid,
      };

  factory CheckItem.fromJson(Map<String, dynamic> json) => CheckItem(
        id: json['id'],
        issuedTo: json['issuedTo'],
        amount: json['amount'].toDouble(),
        issueDate: DateTime.parse(json['issueDate']),
        dueDate: DateTime.parse(json['dueDate']),
        isPaid: json['isPaid'],
      );
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<CheckItem> _checks = [];

  @override
  void initState() {
    super.initState();
    _loadChecks();
  }

  // LOKAL HAFIZADAN VERİ ÇEKME
  Future<void> _loadChecks() async {
    final prefs = await SharedPreferences.getInstance();
    final String? checksString = prefs.getString('saved_checks');
    if (checksString != null) {
      final List<dynamic> decoded = jsonDecode(checksString);
      setState(() {
        _checks = decoded.map((item) => CheckItem.fromJson(item)).toList();
      });
    }
  }

  // LOKAL HAFIZAYA KAYDETME
  Future<void> _saveChecks() async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = jsonEncode(_checks.map((e) => e.toJson()).toList());
    await prefs.setString('saved_checks', encoded);
  }

  // OTOMATİK BİLDİRİM ZAMANLAMA (7 Gün, 2 Gün ve Vade Günü 09:00)
  Future<void> _scheduleNotification(CheckItem check) async {
    final notificationDetails = const NotificationDetails(
      android: AndroidNotificationDetails(
        'check_reminders',
        'Çek Hatırlatıcıları',
        channelDescription: 'Vadesi yaklaşan çek bildirimleri',
        importance: Importance.max,
        priority: Priority.high,
      ),
    );

    List<Duration> offsets = [
      const Duration(days: 7),
      const Duration(days: 2),
      Duration.zero,
    ];

    for (int i = 0; i < offsets.length; i++) {
      DateTime scheduledDate = check.dueDate.subtract(offsets[i]);
      // Saat 09:00'a ayarla
      DateTime notificationTime = DateTime(
        scheduledDate.year,
        scheduledDate.month,
        scheduledDate.day,
        9,
        0,
      );

      if (notificationTime.isAfter(DateTime.now())) {
        await flutterLocalNotificationsPlugin.zonedSchedule(
          check.id.hashCode + i,
          'Çek Vade Hatırlatması',
          '${check.issuedTo} firmasına ait ${formatMoney(check.amount)} tutarındaki çekin vadesi yaklaşmaktadır.',
          tz.TZDateTime.from(notificationTime, tz.local),
          notificationDetails,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    }
  }

  double get _totalPaidAmount {
    return _checks
        .where((c) => c.isPaid)
        .fold(0.0, (sum, item) => sum + item.amount);
  }

  void _addCheck(CheckItem newCheck) {
    setState(() {
      _checks.add(newCheck);
    });
    _saveChecks();
    _scheduleNotification(newCheck);
  }

  void _markAsPaid(String id) {
    setState(() {
      final index = _checks.indexWhere((c) => c.id == id);
      if (index != -1) {
        _checks[index].isPaid = true;
      }
    });
    _saveChecks();
  }

  @override
  Widget build(BuildContext context) {
    final paidChecks = _checks.where((c) => c.isPaid).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ÇEK TAKİP PORTALI',
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2, color: Color(0xFFD4AF37)),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildBigButton(
                    context,
                    title: 'YENİ ÇEK EKLE',
                    icon: Icons.add_card_rounded,
                    bgColor: const Color(0xFF2A2A2A),
                    accentColor: const Color(0xFFD4AF37),
                    onTap: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const AddCheckScreen()),
                      );
                      if (result != null && result is CheckItem) {
                        _addCheck(result);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: _buildBigButton(
                    context,
                    title: 'MEVCUT ÇEKLER',
                    icon: Icons.receipt_long_rounded,
                    bgColor: const Color(0xFF2A2A2A),
                    accentColor: const Color(0xFFE5C158),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExistingChecksScreen(
                            checks: _checks,
                            onMarkAsPaid: _markAsPaid,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PaidChecksScreen(paidChecks: paidChecks),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E1E),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFD4AF37).withOpacity(0.4), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFD4AF37).withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.account_balance_wallet, color: Color(0xFFD4AF37), size: 30),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Bugüne Kadar Ödenen Toplam',
                            style: TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            formatMoney(_totalPaidAmount),
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFD4AF37),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFFD4AF37), size: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBigButton(BuildContext context,
      {required String title,
      required IconData icon,
      required Color bgColor,
      required Color accentColor,
      required VoidCallback onTap}) {
    return SizedBox(
      height: 130,
      child: Material(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 40, color: accentColor),
                const SizedBox(height: 10),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 0.8),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AddCheckScreen extends StatefulWidget {
  const AddCheckScreen({super.key});

  @override
  State<AddCheckScreen> createState() => _AddCheckScreenState();
}

class _AddCheckScreenState extends State<AddCheckScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime _issueDate = DateTime.now();
  DateTime _dueDate = DateTime.now().add(const Duration(days: 30));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yeni Çek Tanımla'),
        backgroundColor: const Color(0xFF1E1E1E),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Kime Kesildiği (Firma/Kişi)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.business, color: Color(0xFFD4AF37)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Lütfen firma adı girin' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Çek Tutarı (₺)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.attach_money, color: Color(0xFFD4AF37)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Lütfen tutar girin' : null,
              ),
              const SizedBox(height: 16),
              Card(
                color: const Color(0xFF1E1E1E),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  title: Text('Kesim Tarihi: ${_issueDate.toString().split(' ')[0]}'),
                  leading: const Icon(Icons.calendar_today, color: Color(0xFFD4AF37)),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _issueDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2030),
                    );
                    if (picked != null) setState(() => _issueDate = picked);
                  },
                ),
              ),
              const SizedBox(height: 8),
              Card(
                color: const Color(0xFF1E1E1E),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  title: Text('Vade Tarihi: ${_dueDate.toString().split(' ')[0]}'),
                  leading: const Icon(Icons.event_available, color: Color(0xFFD4AF37)),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _dueDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2030),
                    );
                    if (picked != null) setState(() => _dueDate = picked);
                  },
                ),
              ),
              const SizedBox(height: 28),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD4AF37),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.all(16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final newCheck = CheckItem(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      issuedTo: _nameController.text,
                      amount: double.parse(_amountController.text.replaceAll(',', '.')),
                      issueDate: _issueDate,
                      dueDate: _dueDate,
                    );
                    Navigator.pop(context, newCheck);
                  }
                },
                child: const Text('ÇEKİ KAYDET', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class ExistingChecksScreen extends StatelessWidget {
  final List<CheckItem> checks;
  final Function(String) onMarkAsPaid;

  const ExistingChecksScreen({super.key, required this.checks, required this.onMarkAsPaid});

  @override
  Widget build(BuildContext context) {
    final activeChecks = checks.where((c) => !c.isPaid).toList();
    activeChecks.sort((a, b) => a.issueDate.compareTo(b.issueDate));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mevcut Aktif Çekler'),
        backgroundColor: const Color(0xFF1E1E1E),
      ),
      body: activeChecks.isEmpty
          ? const Center(child: Text('Aktif ödenmemiş çek bulunmuyor.', style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: activeChecks.length,
              itemBuilder: (context, index) {
                final check = activeChecks[index];
                final remainingDays = check.dueDate.difference(DateTime.now()).inDays;

                return Card(
                  color: const Color(0xFF1E1E1E),
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: Colors.white12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(check.issuedTo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            Text(
                              formatMoney(check.amount),
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFFD4AF37)),
                            ),
                          ],
                        ),
                        const Divider(height: 20, color: Colors.white10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Kesim: ${check.issueDate.toString().split(' ')[0]}\nVade: ${check.dueDate.toString().split(' ')[0]} ($remainingDays gün kaldı)',
                              style: const TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFD4AF37),
                                foregroundColor: Colors.black,
                              ),
                              onPressed: () {
                                onMarkAsPaid(check.id);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Çek ödenenler geçmişine aktarıldı.')),
                                );
                              },
                              child: const Text('Ödendi İşaretle', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class PaidChecksScreen extends StatelessWidget {
  final List<CheckItem> paidChecks;

  const PaidChecksScreen({super.key, required this.paidChecks});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ödenen Çek Geçmişi'),
        backgroundColor: const Color(0xFF1E1E1E),
      ),
      body: paidChecks.isEmpty
          ? const Center(child: Text('Henüz ödenmiş çek bulunmuyor.', style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: paidChecks.length,
              itemBuilder: (context, index) {
                final check = paidChecks[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  color: const Color(0xFF1E1E1E),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: const Icon(Icons.check_circle_rounded, color: Colors.green, size: 32),
                    title: Text(check.issuedTo, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Vade Tarihi: ${check.dueDate.toString().split(' ')[0]}', style: const TextStyle(color: Colors.grey)),
                    trailing: Text(
                      formatMoney(check.amount),
                      style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                );
              },
            ),
    );
  }
}