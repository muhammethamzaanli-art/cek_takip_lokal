package com.cektakip.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
