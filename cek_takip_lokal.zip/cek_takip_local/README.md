# Çek Takip (Lokal Sürüm) — APK'yı Kendiniz Üretme Rehberi

Bu sürüm **Firebase kullanmaz** — çekleriniz telefonun kendi hafızasında
saklanır. Bu yüzden kurulum önceki sürüme göre çok daha kısa: sadece
**GitHub** ve **Codemagic** yeterli. Toplam süre ~10-15 dakika.

## Bu Sürümün Sınırı (Önemli)

- Her cihaz kendi verisini ayrı tutar. **Siz ve babanız aynı çekleri
  görmezsiniz** — bu sürümde bulut senkronizasyonu yok.
- İki cihazın aynı veriyi anlık görebilmesi için Firebase'li (önceki)
  sürümü kullanmanız gerekir.
- Uygulamayı silip yeniden yüklerseniz kayıtlı çekler de silinir (telefon
  hafızasında tutulduğu için).

Eğer paylaşımlı/senkronize kullanım istiyorsanız bana söyleyin, önceki
Firebase'li projeyi bu tasarımla (koyu/gold tema) birleştirip tek bir
sürüm haline getirebilirim.

---

## Adım 1 — GitHub'a Yükleme

1. [github.com](https://github.com) üzerinde ücretsiz hesap açın (yoksa).
2. **+** → **New repository** → isim: `cek-takip-lokal` → **Private** →
   **Create repository**.
3. **"uploading an existing file"** linkine tıklayın.
4. İndirdiğiniz `cek_takip_lokal.zip` dosyasını açın (unzip), içindeki
   **tüm dosya ve klasörleri** (lib, android, pubspec.yaml, codemagic.yaml,
   .gitignore) bu sayfaya sürükleyip bırakın.
5. **Commit changes**.

---

## Adım 2 — Codemagic ile Derleme

1. [codemagic.io](https://codemagic.io) → **Sign up** → **GitHub
   hesabınızla** giriş yapın (ücretsiz, kredi kartı istemez).
2. GitHub depolarınıza erişim isteyecek, **onaylayın**.
3. **Add application** → `cek-takip-lokal` deponuzu seçin.
4. **Flutter App** otomatik algılanır → **Finish Build Setup**.
5. Codemagic, depodaki `codemagic.yaml` dosyasını otomatik bulur ve
   **"android-apk"** iş akışını gösterir.
6. **Start new build** → **android-apk** seçin → **Start build**.
7. ~5-10 dakika sonra **Artifacts** bölümünde `app-release.apk` belirir,
   üzerine tıklayıp indirin.

---

## Adım 3 — Telefona Yükleme

1. İndirdiğiniz `.apk` dosyasını telefonunuza aktarın (WhatsApp'a kendinize
   göndererek, Google Drive veya USB kablosuyla).
2. Dosyaya dokunun, çıkan "Bilinmeyen kaynaklardan yükleme" uyarısında
   **İzin ver** deyip kurulumu tamamlayın.
3. Babanızın telefonuna da aynı apk dosyasını aynı şekilde yükleyebilirsiniz
   — ama unutmayın, verileri **birbirinden bağımsız** olacaktır.

---

## Sorun Yaşarsanız

Codemagic'teki kırmızı hata mesajının tamamını kopyalayıp bana gönderin,
birlikte çözelim.
